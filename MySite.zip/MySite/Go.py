# coding=<utf-8>

from flask import Flask, render_template, flash, url_for, request

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dsfodjshfudskfjldshkgqfkjdslfhdsjlfdshjfdsjk!!!'
colors = ["Red", "Pink", "Orange", "Yellow", "Plum", "Indigo", "Purple", "Peru", "Gray", "Blue", "Lime"]


@app.route('/')
@app.route('/index')
def index():
    print(url_for('index'))
    return render_template('index.html')


@app.route('/m123')
def m123():
    print(url_for('m123'))
    return render_template('m123.html', title="m123")


@app.route('/seminar12')
def seminar12():
    print(url_for('seminar12'))
    return render_template('seminar12.html', colors=colors, title="семинар 1-2")


@app.route('/questionnaire', methods=['POST', 'GET'])
def questionnaire():
    print(url_for('questionnaire'))
    if request.method == 'POST':
        if len(request.form) == 7:
            flash('Форма успешно отправлена')
        print(request.form)
    return render_template('questionnaire.html', title="анкета")

@app.route('/questionnaire2', methods=['POST', 'GET'])
def questionnaire2():
    print(url_for('questionnaire2'))
    if request.method == 'POST':
        print('AAAA', len(request.form))
        if len(request.form) == 7:
            print('aaaaBBBBB')
            flash('Форма успешно отправлена')
        print(request.form)
    return render_template('questionnaire2.html', title="анкета")

@app.route('/questionnaire3', methods=['POST', 'GET'])
def questionnaire3():
    print(url_for('questionnaire3'))
    if request.method == 'POST':
        print('AAAA', len(request.form))
        if len(request.form) == 7:
            print('aaaaBBBBB')
            flash('Форма успешно отправлена')
        print(request.form)
    return render_template('questionnaire3.html', title="анкета")

@app.route("/seminars")
def seminars():
    print(url_for('seminars'))
    return render_template('seminars.html', title='семинары')


if __name__ == '__main__':
    app.run(debug=True)
